<html>
<head>
<title><?=PAGE_TITLE?></title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
<script language="javascript" src="/<?=JS_PATH?>sbh.js"></script>
<link rel="stylesheet" href="/<?=CSS_PATH?>basic.generic.css" type="text/css">
</head>

<body bgcolor="#ffffff" text="#000000" link="#669966" alink="#993333" vlink="#669966">


<div id="wrap">

    <div id="header">
	<table border="0" cellspacing="0" cellpadding="1" width="100%" height="100%">
		<tr>
			<td class="nav" align="left" valign="bottom" nowrap="nowrap">
				<div style="margin-left: 5px;font-weight:bold">
				<a href="/skelecton/Plist">Test</a> &middot;
				<a href="/item_manage/Plist">������ ����</a> &middot;
				<a href="/sell_manage/Plist">�ǸŰ���</a> &middot;
				</div>
			</td>
			<td class="headerdate" align="right" valign="top" nowrap="nowrap">
				<div style="margin-right: 5px">
				</div>
			</td>
		</tr>
		</table>
	</div>

    <div class="sidebar">

	<form id="login" name="login" action="" target="_top" method="post" autocomplete="off" onsubmit="return form_chk();">
		<fieldset>
			<legend>�α���</legend>
			<input type="text" id="loginEmail" name="email" class="bg" title="�̸��� �ּ� �Է�" onfocus="ChgInput(this);" onkeydown="ChgInput(this);" onmouseover="this.focus();" datatype="an" mask="-_@." />

			<input type="password" id="loginPasswd" name="passwd" class="bg" title="��й�ȣ �Է�" onfocus="ChgInput(this);" onkeydown="ChgInput(this);" onmouseover="this.focus();" enc="on" />
			<input type="submit" class="btn" title="�α��ι�ư" value="�α��ι�ư"/>
			<input type="hidden" id="loginEChk" name="echk" value="" />
			<input type="hidden" id="loginSafeChk" name="safechk" value="on" />
		</fieldset>
		</form>


        <ul>
            <li>menu1</li>
            <li>menu2</li>
            <li>menu3</li>
        </ul>

    </div>

   

    <div id="content">

      <?=$MAIN_CONTENT?>

    </div>

    <div style="clear:both;"></div>

	<div id="footer">
		<table border="0" cellspacing="0" cellpadding="5" width="100%">
		<tr class="footer" valign="top">
			<td class="footer" align="center" nowrap="nowrap">
				Copyright &copy; 2008 by
				<a href="http://www.iiooiioo.com">TDMS</a>. All rights reserved.<br />
			</td>
		</tr>
		</table>
	</div>

</div>



</body>
</html>


